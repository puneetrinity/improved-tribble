import { Mail, Phone, MapPin } from "lucide-react";

const Footer = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <footer className="bg-gradient-to-b from-[#1E0B40] to-[#2D1B69] relative overflow-hidden">
      {/* Premium background decorations */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIxIiBjeT0iMSIgcj0iMSIgZmlsbD0id2hpdGUiIGZpbGwtb3BhY2l0eT0iMC4wNSIvPjwvc3ZnPg==')] opacity-10"></div>
      
      {/* Top accent line with animated gradient */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#7B38FB]/30 to-transparent animate-shine"></div>
      
      {/* Premium background glow effects */}
      <div className="absolute top-0 left-1/4 w-64 h-64 bg-[#7B38FB]/5 rounded-full blur-[80px] animate-pulse-slow"></div>
      <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-[#2D81FF]/5 rounded-full blur-[80px] animate-pulse-slow" 
           style={{ animationDelay: '1.2s' }}></div>
           
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-center">
          {/* Premium logo */}
          <div className="mb-4 md:mb-0">
            <a 
              href="#" 
              className="text-2xl font-bold animate-gradient-text font-extrabold tracking-wide"
              onClick={(e) => { e.preventDefault(); scrollToSection("hero"); }}
            >
              VantaHire
            </a>
          </div>
          
          {/* Premium navigation */}
          <div className="flex flex-wrap gap-6 md:gap-8 justify-center">
            {[
              { name: 'About', id: 'about' },
              { name: 'Services', id: 'services' },
              { name: 'Industries', id: 'industries' },
              { name: 'Contact', id: 'contact' }
            ].map((link) => (
              <a 
                key={link.id} 
                href={`#${link.id}`} 
                className="text-white/70 hover:text-white transition-all duration-300 relative group"
                onClick={(e) => { e.preventDefault(); scrollToSection(link.id); }}
              >
                {link.name}
                <span 
                  className="absolute bottom-0 left-0 h-px w-0 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] group-hover:w-full transition-all duration-300"
                ></span>
              </a>
            ))}
          </div>
        </div>
        
        {/* Bottom section with copyright and additional links */}
        <div className="flex flex-col md:flex-row justify-between items-center mt-6 pt-6 border-t border-white/10">
          <div className="text-sm text-white/60 mb-4 md:mb-0 animate-gradient-text">
            &copy; 2025 VantaHire. All rights reserved.
          </div>
          
          <div className="flex flex-wrap gap-4 md:gap-6 justify-center">
            {['Privacy Policy', 'Terms of Service', 'Cookie Policy'].map((text, index) => (
              <a 
                key={text} 
                href="#" 
                className="text-sm text-white/60 hover:text-white transition-all duration-300 relative group"
                onClick={(e) => e.preventDefault()}
              >
                {text}
                <span 
                  className="absolute bottom-0 left-0 h-px w-0 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] group-hover:w-full transition-all duration-300"
                  style={{ animationDelay: `${index * 0.1}s` }}
                ></span>
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
