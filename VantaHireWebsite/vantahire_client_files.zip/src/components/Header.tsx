import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Menu, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrollPosition, setScrollPosition] = useState(0);
  const [activeSection, setActiveSection] = useState("hero");
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  // Track scroll position for header effects
  useEffect(() => {
    const handleScroll = () => {
      setScrollPosition(window.scrollY);
      
      // Determine active section based on scroll position
      const sections = ["hero", "about", "services", "industries", "contact"];
      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 100 && rect.bottom >= 100) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setActiveSection(id);
    }
    setIsMenuOpen(false);
  };

  return (
    <header className={`fixed top-0 left-0 right-0 transition-all duration-500 z-50 
      ${scrollPosition > 50 
        ? 'bg-gradient-to-r from-[#1E0B40]/90 to-[#2D1B69]/90 backdrop-blur-lg shadow-lg py-3 border-b border-white/5' 
        : 'py-6'}`}
    >
      {/* Premium background glow effects */}
      <div className={`absolute inset-0 -z-10 transition-opacity duration-700 ${scrollPosition > 50 ? 'opacity-100' : 'opacity-0'}`}>
        <div className="absolute left-1/4 w-48 h-12 bg-[#7B38FB]/10 rounded-full blur-[50px] animate-pulse-slow"></div>
        <div className="absolute right-1/4 w-48 h-12 bg-[#2D81FF]/10 rounded-full blur-[50px] animate-pulse-slow" 
             style={{ animationDelay: '1.2s' }}></div>
      </div>
      
      {/* Bottom accent line with animated gradient */}
      <div className={`absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#7B38FB]/40 to-transparent animate-shine 
                      transition-opacity duration-500 ${scrollPosition > 50 ? 'opacity-100' : 'opacity-0'}`}>
      </div>
      
      <nav className="container mx-auto px-4 flex items-center justify-between">
        {/* Premium logo styling */}
        <div className="text-2xl font-bold relative group">
          <a 
            href="#" 
            className="animate-gradient-text font-extrabold tracking-wide" 
            onClick={(e) => { e.preventDefault(); scrollToSection("hero"); }}
          >
            VantaHire
          </a>
          {/* Subtle glow effect on hover */}
          <div className="absolute -inset-1 rounded-full blur-md bg-gradient-to-r from-[#7B38FB]/0 via-[#7B38FB]/0 to-[#FF5BA8]/0 
                        group-hover:from-[#7B38FB]/10 group-hover:via-[#7B38FB]/20 group-hover:to-[#FF5BA8]/10 
                        opacity-0 group-hover:opacity-100 transition-all duration-700 -z-10"></div>
        </div>
        
        {/* Enhanced desktop menu */}
        <div className="hidden md:flex items-center space-x-8">
          {/* Navigation links with premium hover effects */}
          <a 
            href="#about" 
            className={`relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group ${
              activeSection === "about" ? 'text-white font-medium' : 'text-white/70'
            }`}
            onClick={(e) => { e.preventDefault(); scrollToSection("about"); }}
          >
            <span className="relative z-10">About</span>
            
            {/* Animated underline with gradient */}
            <span 
              className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 
                        ${activeSection === "about" ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}
            ></span>
            
            {/* Subtle highlight on hover/active */}
            <span 
              className={`absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md
                        ${activeSection === "about" ? 'bg-white/5' : ''}`}
            ></span>
          </a>
          
          <a 
            href="#services" 
            className={`relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group ${
              activeSection === "services" ? 'text-white font-medium' : 'text-white/70'
            }`}
            onClick={(e) => { e.preventDefault(); scrollToSection("services"); }}
          >
            <span className="relative z-10">Services</span>
            
            <span 
              className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 
                        ${activeSection === "services" ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}
            ></span>
            
            <span 
              className={`absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md
                        ${activeSection === "services" ? 'bg-white/5' : ''}`}
            ></span>
          </a>
          
          <a 
            href="#industries" 
            className={`relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group ${
              activeSection === "industries" ? 'text-white font-medium' : 'text-white/70'
            }`}
            onClick={(e) => { e.preventDefault(); scrollToSection("industries"); }}
          >
            <span className="relative z-10">Industries</span>
            
            <span 
              className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 
                        ${activeSection === "industries" ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}
            ></span>
            
            <span 
              className={`absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md
                        ${activeSection === "industries" ? 'bg-white/5' : ''}`}
            ></span>
          </a>
          
          <a 
            href="#contact" 
            className={`relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group ${
              activeSection === "contact" ? 'text-white font-medium' : 'text-white/70'
            }`}
            onClick={(e) => { e.preventDefault(); scrollToSection("contact"); }}
          >
            <span className="relative z-10">Contact</span>
            
            <span 
              className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 
                        ${activeSection === "contact" ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}
            ></span>
            
            <span 
              className={`absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md
                        ${activeSection === "contact" ? 'bg-white/5' : ''}`}
            ></span>
          </a>

          {/* Jobs link */}
          <Link href="/jobs" className="relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group text-white/70 hover:text-white">
            <span className="relative z-10">Jobs</span>
            <span className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 scale-x-0 group-hover:scale-x-100"></span>
            <span className="absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md"></span>
          </Link>

          {/* Admin links for admin users */}
          {user && user.role === 'admin' && (
            <>
              <Link href="/admin" className="relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group text-white/70 hover:text-white">
                <span className="relative z-10">Admin</span>
                <span className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 scale-x-0 group-hover:scale-x-100"></span>
                <span className="absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md"></span>
              </Link>
              <Link href="/admin/super" className="relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group text-white/70 hover:text-white">
                <span className="relative z-10">Super Admin</span>
                <span className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 scale-x-0 group-hover:scale-x-100"></span>
                <span className="absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md"></span>
              </Link>
            </>
          )}

          {/* Analytics link for recruiters and admins */}
          {user && (user.role === 'recruiter' || user.role === 'admin') && (
            <Link href="/analytics" className="relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group text-white/70 hover:text-white">
              <span className="relative z-10">Analytics</span>
              <span className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 scale-x-0 group-hover:scale-x-100"></span>
              <span className="absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md"></span>
            </Link>
          )}

          {/* Dashboard link for authenticated users */}
          {user && (
            <Link href="/my-dashboard" className="relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group text-white/70 hover:text-white">
              <span className="relative z-10">My Dashboard</span>
              <span className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 scale-x-0 group-hover:scale-x-100"></span>
              <span className="absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md"></span>
            </Link>
          )}

          {/* Auth links */}
          {user ? (
            <div className="flex items-center space-x-4">
              <span className="text-white/70 text-sm">Welcome, {user.firstName}</span>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => logoutMutation.mutate()}
                className="border-white/20 text-white hover:bg-white/10"
              >
                Logout
              </Button>
            </div>
          ) : (
            <Link href="/auth" className="relative px-3 py-2 hover:text-white transition-all duration-300 overflow-hidden group text-white/70 hover:text-white">
              <span className="relative z-10">Login</span>
              <span className="absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-[#7B38FB] to-[#FF5BA8] w-full transform origin-left transition-transform duration-300 scale-x-0 group-hover:scale-x-100"></span>
              <span className="absolute inset-0 -z-10 bg-white/0 group-hover:bg-white/5 transition-colors duration-300 rounded-md"></span>
            </Link>
          )}
          
          {/* Enhanced consultation button */}
          <Button 
            variant="gradient" 
            size="lg" 
            className="rounded-full premium-card hover:scale-105 transform transition-all duration-300 group shadow-lg"
            onClick={() => window.open('https://calendly.com/vantahire/30min', '_blank')}
          >
            <span className="group-hover:tracking-wide transition-all duration-300">
              Schedule a Free Consultation
            </span>
          </Button>
        </div>
        
        {/* Enhanced mobile menu button */}
        <button
          className="md:hidden text-white hover:bg-white/10 p-2 rounded-full transition-all duration-300 hover:scale-110
                    border border-white/0 hover:border-white/10 backdrop-blur-lg"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          <Menu className="h-6 w-6" />
        </button>
      </nav>

      {/* Mobile menu */}
      <div className={cn(
        "fixed top-0 left-0 right-0 bottom-0 bg-[hsl(var(--vanta-dark))]/95 backdrop-blur-lg z-50 p-6 transition-all duration-500 flex flex-col",
        isMenuOpen ? "translate-x-0 opacity-100" : "translate-x-full opacity-0"
      )}>
        <div className="flex justify-between items-center mb-8">
          <div className="text-2xl font-bold">
            <a href="#" className="animate-gradient-text font-extrabold" onClick={() => scrollToSection("hero")}>
              VantaHire
            </a>
          </div>
          <button
            className="text-white hover:bg-white/10 p-2 rounded-full transition-all"
            onClick={toggleMenu}
            aria-label="Close menu"
          >
            <X className="h-6 w-6" />
          </button>
        </div>
        <div className="flex flex-col space-y-6">
          <a 
            href="#about" 
            className={`text-xl relative px-2 py-1 ${activeSection === "about" ? 'text-white' : 'text-white/70'} 
                      transition-all duration-300 border-l-2 pl-4 ${activeSection === "about" ? 'border-[#7B38FB]' : 'border-transparent'}`}
            onClick={(e) => { e.preventDefault(); scrollToSection("about"); }}
          >
            About
          </a>
          <a 
            href="#services" 
            className={`text-xl relative px-2 py-1 ${activeSection === "services" ? 'text-white' : 'text-white/70'} 
                      transition-all duration-300 border-l-2 pl-4 ${activeSection === "services" ? 'border-[#7B38FB]' : 'border-transparent'}`}
            onClick={(e) => { e.preventDefault(); scrollToSection("services"); }}
          >
            Services
          </a>
          <a 
            href="#industries" 
            className={`text-xl relative px-2 py-1 ${activeSection === "industries" ? 'text-white' : 'text-white/70'} 
                      transition-all duration-300 border-l-2 pl-4 ${activeSection === "industries" ? 'border-[#7B38FB]' : 'border-transparent'}`}
            onClick={(e) => { e.preventDefault(); scrollToSection("industries"); }}
          >
            Industries
          </a>
          <a 
            href="#contact" 
            className={`text-xl relative px-2 py-1 ${activeSection === "contact" ? 'text-white' : 'text-white/70'} 
                      transition-all duration-300 border-l-2 pl-4 ${activeSection === "contact" ? 'border-[#7B38FB]' : 'border-transparent'}`}
            onClick={(e) => { e.preventDefault(); scrollToSection("contact"); }}
          >
            Contact
          </a>

          {/* Mobile Jobs link */}
          <Link 
            href="/jobs"
            className="text-xl relative px-2 py-1 text-white/70 transition-all duration-300 border-l-2 pl-4 border-transparent hover:text-white hover:border-[#7B38FB]"
            onClick={() => setIsMenuOpen(false)}
          >
            Jobs
          </Link>

          {/* Mobile Admin link */}
          {user && user.role === 'admin' && (
            <Link 
              href="/admin"
              className="text-xl relative px-2 py-1 text-white/70 transition-all duration-300 border-l-2 pl-4 border-transparent hover:text-white hover:border-[#7B38FB]"
              onClick={() => setIsMenuOpen(false)}
            >
              Admin
            </Link>
          )}

          {/* Mobile Auth links */}
          {user ? (
            <div className="flex flex-col space-y-4 mt-4">
              <span className="text-white/70 px-2">Welcome, {user.firstName}</span>
              <Button 
                variant="outline" 
                onClick={() => {
                  logoutMutation.mutate();
                  setIsMenuOpen(false);
                }}
                className="border-white/20 text-white hover:bg-white/10 w-full"
              >
                Logout
              </Button>
            </div>
          ) : (
            <Link 
              href="/auth"
              className="text-xl relative px-2 py-1 text-white/70 transition-all duration-300 border-l-2 pl-4 border-transparent hover:text-white hover:border-[#7B38FB]"
              onClick={() => setIsMenuOpen(false)}
            >
              Login
            </Link>
          )}
          
          <div className="mt-8">
            <Button 
              variant="gradient" 
              size="lg" 
              className="rounded-full w-full hover:shadow-lg hover:scale-105 transition-all duration-300"
              onClick={() => window.open('https://calendly.com/vantahire/30min', '_blank')}
            >
              Schedule a Free Consultation
            </Button>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -z-10 w-32 h-32 rounded-full blur-3xl bg-[#7B38FB]/20 top-1/4 right-1/4"></div>
        <div className="absolute -z-10 w-32 h-32 rounded-full blur-3xl bg-[#FF5BA8]/20 bottom-1/4 left-1/4"></div>
      </div>
    </header>
  );
};

export default Header;
