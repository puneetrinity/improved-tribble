import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Job } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { CheckCircle, XCircle, Clock, Eye, MessageSquare, Calendar, User, MapPin, Briefcase } from "lucide-react";
import Layout from "@/components/Layout";

interface AdminJobsResponse {
  jobs: Job[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

export default function AdminDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedTab, setSelectedTab] = useState("pending");
  const [reviewComments, setReviewComments] = useState<{ [key: number]: string }>({});

  // Redirect if not admin
  if (!user || user.role !== 'admin') {
    return <Redirect to="/auth" />;
  }

  const { data: pendingJobs, isLoading: loadingPending } = useQuery<AdminJobsResponse>({
    queryKey: ['/api/admin/jobs', 'pending'],
    queryFn: () => fetch('/api/admin/jobs?status=pending').then(res => res.json()),
  });

  const { data: approvedJobs, isLoading: loadingApproved } = useQuery<AdminJobsResponse>({
    queryKey: ['/api/admin/jobs', 'approved'],
    queryFn: () => fetch('/api/admin/jobs?status=approved').then(res => res.json()),
  });

  const { data: declinedJobs, isLoading: loadingDeclined } = useQuery<AdminJobsResponse>({
    queryKey: ['/api/admin/jobs', 'declined'],
    queryFn: () => fetch('/api/admin/jobs?status=declined').then(res => res.json()),
  });

  const reviewJobMutation = useMutation({
    mutationFn: async ({ jobId, status, comments }: { jobId: number; status: string; comments?: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/jobs/${jobId}/review`, {
        status,
        reviewComments: comments
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/jobs'] });
      toast({
        title: "Job reviewed successfully",
        description: "The job status has been updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Review failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleReviewJob = (jobId: number, status: 'approved' | 'declined') => {
    const comments = reviewComments[jobId] || '';
    reviewJobMutation.mutate({ jobId, status, comments });
    setReviewComments(prev => ({ ...prev, [jobId]: '' }));
  };

  const formatDate = (dateString: string | Date) => {
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-300"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="secondary" className="bg-green-500/20 text-green-300"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'declined':
        return <Badge variant="secondary" className="bg-red-500/20 text-red-300"><XCircle className="w-3 h-3 mr-1" />Declined</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const JobCard = ({ job }: { job: Job }) => (
    <Card className="mb-6 bg-white/10 backdrop-blur-sm border-white/20">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-white text-xl mb-2">{job.title}</CardTitle>
            <CardDescription className="text-gray-300">
              <div className="flex items-center gap-4 mb-2">
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {job.location}
                </span>
                <span className="flex items-center gap-1">
                  <Briefcase className="w-4 h-4" />
                  {job.type}
                </span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Posted {formatDate(job.createdAt.toString())}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1">
                  <User className="w-4 h-4" />
                  Job ID: {job.id}
                </span>
                {getStatusBadge(job.status)}
              </div>
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-4">
          <p className="text-gray-300 mb-3 line-clamp-3">{job.description}</p>
          {job.skills && job.skills.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {job.skills.map((skill, index) => (
                <Badge key={index} variant="outline" className="border-purple-400/30 text-purple-300">
                  {skill}
                </Badge>
              ))}
            </div>
          )}
        </div>

        {job.status === 'pending' && (
          <div className="space-y-4">
            <div>
              <Label htmlFor={`comments-${job.id}`} className="text-white mb-2 block">
                Review Comments (Optional)
              </Label>
              <Textarea
                id={`comments-${job.id}`}
                placeholder="Add comments about this job posting..."
                value={reviewComments[job.id] || ''}
                onChange={(e) => setReviewComments(prev => ({ ...prev, [job.id]: e.target.value }))}
                className="bg-white/5 border-white/20 text-white placeholder:text-gray-400"
              />
            </div>
            <div className="flex gap-3">
              <Button
                onClick={() => handleReviewJob(job.id, 'approved')}
                disabled={reviewJobMutation.isPending}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                Approve
              </Button>
              <Button
                onClick={() => handleReviewJob(job.id, 'declined')}
                disabled={reviewJobMutation.isPending}
                variant="destructive"
              >
                <XCircle className="w-4 h-4 mr-2" />
                Decline
              </Button>
            </div>
          </div>
        )}

        {job.reviewComments && (
          <div className="mt-4 p-3 bg-white/5 rounded-lg border-l-4 border-purple-400">
            <div className="flex items-center gap-2 mb-2">
              <MessageSquare className="w-4 h-4 text-purple-400" />
              <span className="text-purple-400 font-medium">Admin Review</span>
            </div>
            <p className="text-gray-300 text-sm">{job.reviewComments}</p>
            {job.reviewedAt && (
              <p className="text-gray-400 text-xs mt-1">
                Reviewed on {formatDate(job.reviewedAt.toString())}
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-white mb-4">
              Admin <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">Dashboard</span>
            </h1>
            <p className="text-xl text-gray-300">
              Review and manage job postings
            </p>
          </div>

          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-300 text-sm">Pending Review</p>
                    <p className="text-3xl font-bold text-yellow-400">
                      {pendingJobs?.pagination.total || 0}
                    </p>
                  </div>
                  <Clock className="w-8 h-8 text-yellow-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-300 text-sm">Approved Jobs</p>
                    <p className="text-3xl font-bold text-green-400">
                      {approvedJobs?.pagination.total || 0}
                    </p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-green-400" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/10 backdrop-blur-sm border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-300 text-sm">Declined Jobs</p>
                    <p className="text-3xl font-bold text-red-400">
                      {declinedJobs?.pagination.total || 0}
                    </p>
                  </div>
                  <XCircle className="w-8 h-8 text-red-400" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Super Admin Access */}
          <Card className="mb-6 bg-gradient-to-r from-purple-600/20 to-blue-600/20 backdrop-blur-sm border-purple-400/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Super Admin Dashboard</h3>
                  <p className="text-gray-300">Access complete platform control with comprehensive statistics, user management, and system oversight.</p>
                </div>
                <Button
                  onClick={() => window.location.href = '/admin/super'}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-6 py-3 font-semibold"
                >
                  Launch Super Admin
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Job Review Tabs */}
          <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-white/10 border-white/20">
              <TabsTrigger value="pending" className="data-[state=active]:bg-yellow-500/20 data-[state=active]:text-yellow-300">
                Pending ({pendingJobs?.pagination.total || 0})
              </TabsTrigger>
              <TabsTrigger value="approved" className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-300">
                Approved ({approvedJobs?.pagination.total || 0})
              </TabsTrigger>
              <TabsTrigger value="declined" className="data-[state=active]:bg-red-500/20 data-[state=active]:text-red-300">
                Declined ({declinedJobs?.pagination.total || 0})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="pending" className="mt-6">
              {loadingPending ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400 mx-auto"></div>
                  <p className="text-white mt-4">Loading pending jobs...</p>
                </div>
              ) : (
                <div>
                  {pendingJobs?.jobs.length === 0 ? (
                    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                      <CardContent className="p-8 text-center">
                        <Clock className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-white mb-2">No Pending Jobs</h3>
                        <p className="text-gray-300">All job postings have been reviewed.</p>
                      </CardContent>
                    </Card>
                  ) : (
                    pendingJobs?.jobs.map(job => <JobCard key={job.id} job={job} />)
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="approved" className="mt-6">
              {loadingApproved ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400 mx-auto"></div>
                  <p className="text-white mt-4">Loading approved jobs...</p>
                </div>
              ) : (
                <div>
                  {approvedJobs?.jobs.length === 0 ? (
                    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                      <CardContent className="p-8 text-center">
                        <CheckCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-white mb-2">No Approved Jobs</h3>
                        <p className="text-gray-300">No jobs have been approved yet.</p>
                      </CardContent>
                    </Card>
                  ) : (
                    approvedJobs?.jobs.map(job => <JobCard key={job.id} job={job} />)
                  )}
                </div>
              )}
            </TabsContent>

            <TabsContent value="declined" className="mt-6">
              {loadingDeclined ? (
                <div className="text-center py-8">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400 mx-auto"></div>
                  <p className="text-white mt-4">Loading declined jobs...</p>
                </div>
              ) : (
                <div>
                  {declinedJobs?.jobs.length === 0 ? (
                    <Card className="bg-white/10 backdrop-blur-sm border-white/20">
                      <CardContent className="p-8 text-center">
                        <XCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-xl font-semibold text-white mb-2">No Declined Jobs</h3>
                        <p className="text-gray-300">No jobs have been declined yet.</p>
                      </CardContent>
                    </Card>
                  ) : (
                    declinedJobs?.jobs.map(job => <JobCard key={job.id} job={job} />)
                  )}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </Layout>
  );
}